package com.example.payment.dto;

public record ProviderPaymentResponse(
        boolean success,
        String providerTransactionId,
        String message
) {
}
