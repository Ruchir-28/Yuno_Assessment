package com.example.payment.dto;

import com.example.payment.enums.PaymentMethod;
import com.example.payment.enums.PaymentStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public record PaymentResponse(
        UUID paymentId,
        BigDecimal amount,
        String currency,
        PaymentMethod paymentMethod,
        PaymentStatus status,
        String providerName,
        String providerTransactionId,
        String failureReason,
        Instant createdAt,
        Instant updatedAt
) {
}
