package com.example.payment.provider;

import com.example.payment.dto.CreatePaymentRequest;
import com.example.payment.dto.ProviderPaymentResponse;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class ProviderBConnector implements PaymentProvider {

    @Override
    public String getName() {
        return "PROVIDER_B";
    }

    @Override
    public ProviderPaymentResponse process(CreatePaymentRequest request) {
        return new ProviderPaymentResponse(
                true,
                "B-" + UUID.randomUUID(),
                "Payment processed successfully by Provider B"
        );
    }
}
