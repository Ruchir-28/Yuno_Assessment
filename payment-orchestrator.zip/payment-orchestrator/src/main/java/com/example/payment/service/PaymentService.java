package com.example.payment.service;

import com.example.payment.dto.CreatePaymentRequest;
import com.example.payment.dto.PaymentResponse;
import com.example.payment.dto.ProviderPaymentResponse;
import com.example.payment.entity.Payment;
import com.example.payment.enums.PaymentStatus;
import com.example.payment.exception.PaymentNotFoundException;
import com.example.payment.provider.PaymentProvider;
import com.example.payment.repository.PaymentRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final RoutingEngine routingEngine;
    private final IdempotencyService idempotencyService;

    public PaymentService(
            PaymentRepository paymentRepository,
            RoutingEngine routingEngine,
            IdempotencyService idempotencyService
    ) {
        this.paymentRepository = paymentRepository;
        this.routingEngine = routingEngine;
        this.idempotencyService = idempotencyService;
    }

    @Transactional
    public PaymentResponse createPayment(CreatePaymentRequest request, String idempotencyKey) {

        if (idempotencyKey != null && !idempotencyKey.isBlank()) {
            UUID existingPaymentId = idempotencyService.findExistingPaymentId(idempotencyKey);

            if (existingPaymentId != null) {
                Payment existingPayment = paymentRepository.findById(existingPaymentId)
                        .orElseThrow(() -> new PaymentNotFoundException(existingPaymentId));

                return toResponse(existingPayment);
            }
        }

        Payment payment = new Payment();
        payment.setAmount(request.amount());
        payment.setCurrency(request.currency().toUpperCase());
        payment.setPaymentMethod(request.paymentMethod());
        payment.setCustomerId(request.customerId());
        payment.setStatus(PaymentStatus.INITIATED);
        payment.setCreatedAt(Instant.now());
        payment.setUpdatedAt(Instant.now());

        payment = paymentRepository.save(payment);

        idempotencyService.save(idempotencyKey, payment.getId());

        payment.setStatus(PaymentStatus.PROCESSING);
        payment.setUpdatedAt(Instant.now());
        payment = paymentRepository.save(payment);

        List<PaymentProvider> providers = routingEngine.resolveProviders(request.paymentMethod());

        String lastFailureReason = null;

        for (PaymentProvider provider : providers) {
            try {
                ProviderPaymentResponse providerResponse = provider.process(request);

                payment.setProviderName(provider.getName());
                payment.setProviderTransactionId(providerResponse.providerTransactionId());
                payment.setUpdatedAt(Instant.now());

                if (providerResponse.success()) {
                    payment.setStatus(PaymentStatus.SUCCESS);
                    payment.setFailureReason(null);

                    Payment savedPayment = paymentRepository.save(payment);
                    return toResponse(savedPayment);
                }

                lastFailureReason = providerResponse.message();

            } catch (Exception exception) {
                lastFailureReason = exception.getMessage();
            }
        }

        payment.setStatus(PaymentStatus.FAILED);
        payment.setFailureReason(lastFailureReason != null ? lastFailureReason : "All providers failed");
        payment.setUpdatedAt(Instant.now());

        Payment failedPayment = paymentRepository.save(payment);
        return toResponse(failedPayment);
    }

    public PaymentResponse getPayment(UUID paymentId) {
        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new PaymentNotFoundException(paymentId));

        return toResponse(payment);
    }

    private PaymentResponse toResponse(Payment payment) {
        return new PaymentResponse(
                payment.getId(),
                payment.getAmount(),
                payment.getCurrency(),
                payment.getPaymentMethod(),
                payment.getStatus(),
                payment.getProviderName(),
                payment.getProviderTransactionId(),
                payment.getFailureReason(),
                payment.getCreatedAt(),
                payment.getUpdatedAt()
        );
    }
}