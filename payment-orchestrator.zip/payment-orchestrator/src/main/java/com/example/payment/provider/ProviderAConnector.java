package com.example.payment.provider;

import com.example.payment.dto.CreatePaymentRequest;
import com.example.payment.dto.ProviderPaymentResponse;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class ProviderAConnector implements PaymentProvider {

    @Override
    public String getName() {
        return "PROVIDER_A";
    }

    @Override
    public ProviderPaymentResponse process(CreatePaymentRequest request) {
        return new ProviderPaymentResponse(
                true,
                "A-" + UUID.randomUUID(),
                "Payment processed successfully by Provider A"
        );
    }
}
