package com.example.payment.controller;

import com.example.payment.dto.CreatePaymentRequest;
import com.example.payment.dto.PaymentResponse;
import com.example.payment.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/payments")
public class PaymentController {

	private final PaymentService paymentService;

	public PaymentController(PaymentService paymentService) {
		this.paymentService = paymentService;
	}

	@PostMapping
	public ResponseEntity<PaymentResponse> createPayment(@Valid @RequestBody CreatePaymentRequest request,
			@RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey) {
		PaymentResponse response = null;
		ResponseEntity<PaymentResponse> res = null;
		try {
			response = paymentService.createPayment(request, idempotencyKey);
			res = ResponseEntity.status(HttpStatus.CREATED).body(response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	@GetMapping("/{paymentId}")
	public ResponseEntity<PaymentResponse> getPayment(@PathVariable UUID paymentId) {
		return ResponseEntity.ok(paymentService.getPayment(paymentId));
	}
}
