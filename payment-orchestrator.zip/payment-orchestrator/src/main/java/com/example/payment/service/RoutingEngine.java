package com.example.payment.service;

import com.example.payment.enums.PaymentMethod;
import com.example.payment.provider.PaymentProvider;
import com.example.payment.provider.ProviderAConnector;
import com.example.payment.provider.ProviderBConnector;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoutingEngine {

    private final ProviderAConnector providerAConnector;
    private final ProviderBConnector providerBConnector;

    public RoutingEngine(ProviderAConnector providerAConnector, ProviderBConnector providerBConnector) {
        this.providerAConnector = providerAConnector;
        this.providerBConnector = providerBConnector;
    }

    public List<PaymentProvider> resolveProviders(PaymentMethod paymentMethod) {
        return switch (paymentMethod) {
            case CARD -> List.of(providerAConnector, providerBConnector);
            case UPI -> List.of(providerBConnector, providerAConnector);
        };
    }
}
