package com.example.payment.service;

import com.example.payment.entity.IdempotencyRecord;
import com.example.payment.repository.IdempotencyRepository;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

@Service
public class IdempotencyService {

    private final IdempotencyRepository idempotencyRepository;

    public IdempotencyService(IdempotencyRepository idempotencyRepository) {
        this.idempotencyRepository = idempotencyRepository;
    }

    public UUID findExistingPaymentId(String idempotencyKey) {
        if (idempotencyKey == null || idempotencyKey.isBlank()) {
            return null;
        }

        Optional<IdempotencyRecord> existingRecord =
                idempotencyRepository.findByIdempotencyKey(idempotencyKey);

        return existingRecord
                .map(IdempotencyRecord::getPaymentId)
                .orElse(null);
    }

    public void save(String idempotencyKey, UUID paymentId) {
        if (idempotencyKey == null || idempotencyKey.isBlank()) {
            return;
        }

        Optional<IdempotencyRecord> existingRecord =
                idempotencyRepository.findByIdempotencyKey(idempotencyKey);

        if (existingRecord.isPresent()) {
            return;
        }

        IdempotencyRecord record = new IdempotencyRecord();
        record.setIdempotencyKey(idempotencyKey);
        record.setPaymentId(paymentId);
        record.setCreatedAt(Instant.now());

        idempotencyRepository.save(record);
    }
}