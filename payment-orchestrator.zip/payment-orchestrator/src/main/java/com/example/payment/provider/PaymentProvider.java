package com.example.payment.provider;

import com.example.payment.dto.CreatePaymentRequest;
import com.example.payment.dto.ProviderPaymentResponse;

public interface PaymentProvider {
    String getName();
    ProviderPaymentResponse process(CreatePaymentRequest request);
}
