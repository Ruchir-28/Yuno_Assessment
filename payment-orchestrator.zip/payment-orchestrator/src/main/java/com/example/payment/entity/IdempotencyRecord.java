package com.example.payment.entity;

import jakarta.persistence.*;

import java.time.Instant;
import java.util.UUID;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Entity
@Table(name = "idempotency_records", uniqueConstraints = {
		@UniqueConstraint(name = "uk_idempotency_key", columnNames = "idempotency_key") })
public class IdempotencyRecord {

	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	@JdbcTypeCode(SqlTypes.VARCHAR)
	@Column(name = "id", length = 36, nullable = false, updatable = false)
	private UUID id;

	@Column(name = "idempotency_key", nullable = false, unique = true)
	private String idempotencyKey;

	@JdbcTypeCode(SqlTypes.VARCHAR)
	@Column(name = "payment_id", length = 36, nullable = false)
	private UUID paymentId;

	@Column(name = "created_at", nullable = false)
	private Instant createdAt;

	public IdempotencyRecord() {
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getIdempotencyKey() {
		return idempotencyKey;
	}

	public void setIdempotencyKey(String idempotencyKey) {
		this.idempotencyKey = idempotencyKey;
	}

	public UUID getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(UUID paymentId) {
		this.paymentId = paymentId;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}

	@PrePersist
	public void prePersist() {
		if (createdAt == null) {
			createdAt = Instant.now();
		}
	}
}