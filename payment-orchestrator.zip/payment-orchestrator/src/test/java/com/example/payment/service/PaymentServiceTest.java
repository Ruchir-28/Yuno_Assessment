package com.example.payment.service;

import com.example.payment.dto.CreatePaymentRequest;
import com.example.payment.dto.PaymentResponse;
import com.example.payment.dto.ProviderPaymentResponse;
import com.example.payment.entity.Payment;
import com.example.payment.enums.PaymentMethod;
import com.example.payment.enums.PaymentStatus;
import com.example.payment.provider.PaymentProvider;
import com.example.payment.repository.PaymentRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PaymentServiceTest {

    @Mock
    private PaymentRepository paymentRepository;

    @Mock
    private RoutingEngine routingEngine;

    @Mock
    private IdempotencyService idempotencyService;

    @Mock
    private PaymentProvider providerA;

    @Mock
    private PaymentProvider providerB;

    @InjectMocks
    private PaymentService paymentService;

    @Test
    void shouldCreateCardPaymentUsingProviderA() {
        CreatePaymentRequest request = new CreatePaymentRequest(
                BigDecimal.valueOf(100), "INR", PaymentMethod.CARD, "cust-1"
        );

        when(idempotencyService.findExistingPaymentId("key-1")).thenReturn(Optional.empty());
        when(routingEngine.resolveProviders(PaymentMethod.CARD)).thenReturn(List.of(providerA, providerB));
        when(providerA.getName()).thenReturn("PROVIDER_A");
        when(providerA.process(request)).thenReturn(new ProviderPaymentResponse(true, "A-123", "success"));
        when(paymentRepository.save(any(Payment.class))).thenAnswer(invocation -> {
            Payment p = invocation.getArgument(0);
            if (p.getId() == null) {
                p.setId(UUID.randomUUID());
            }
            if (p.getCreatedAt() == null) {
                p.setCreatedAt(Instant.now());
            }
            p.setUpdatedAt(Instant.now());
            return p;
        });

        PaymentResponse response = paymentService.createPayment(request, "key-1");

        assertThat(response.status()).isEqualTo(PaymentStatus.SUCCESS);
        assertThat(response.providerName()).isEqualTo("PROVIDER_A");
        assertThat(response.providerTransactionId()).isEqualTo("A-123");
        verify(providerB, never()).process(any());
    }

    @Test
    void shouldFailoverToProviderBWhenProviderAFails() {
        CreatePaymentRequest request = new CreatePaymentRequest(
                BigDecimal.valueOf(100), "INR", PaymentMethod.CARD, "cust-1"
        );

        when(idempotencyService.findExistingPaymentId("key-2")).thenReturn(Optional.empty());
        when(routingEngine.resolveProviders(PaymentMethod.CARD)).thenReturn(List.of(providerA, providerB));
        when(providerA.getName()).thenReturn("PROVIDER_A");
        when(providerB.getName()).thenReturn("PROVIDER_B");
        when(providerA.process(request)).thenReturn(new ProviderPaymentResponse(false, null, "declined"));
        when(providerB.process(request)).thenReturn(new ProviderPaymentResponse(true, "B-999", "success"));
        when(paymentRepository.save(any(Payment.class))).thenAnswer(invocation -> {
            Payment p = invocation.getArgument(0);
            if (p.getId() == null) {
                p.setId(UUID.randomUUID());
            }
            if (p.getCreatedAt() == null) {
                p.setCreatedAt(Instant.now());
            }
            p.setUpdatedAt(Instant.now());
            return p;
        });

        PaymentResponse response = paymentService.createPayment(request, "key-2");

        assertThat(response.status()).isEqualTo(PaymentStatus.SUCCESS);
        assertThat(response.providerName()).isEqualTo("PROVIDER_B");
        assertThat(response.providerTransactionId()).isEqualTo("B-999");
    }

    @Test
    void shouldReturnExistingPaymentForSameIdempotencyKey() {
        UUID paymentId = UUID.randomUUID();
        Payment existing = Payment.builder()
                .id(paymentId)
                .amount(BigDecimal.TEN)
                .currency("INR")
                .paymentMethod(PaymentMethod.UPI)
                .status(PaymentStatus.SUCCESS)
                .customerId("cust-1")
                .providerName("PROVIDER_B")
                .providerTransactionId("B-111")
                .createdAt(Instant.now())
                .updatedAt(Instant.now())
                .build();

        when(idempotencyService.findExistingPaymentId("same-key")).thenReturn(Optional.of(paymentId));
        when(paymentRepository.findById(paymentId)).thenReturn(Optional.of(existing));

        CreatePaymentRequest request = new CreatePaymentRequest(
                BigDecimal.TEN, "INR", PaymentMethod.UPI, "cust-1"
        );

        PaymentResponse response = paymentService.createPayment(request, "same-key");

        assertThat(response.paymentId()).isEqualTo(paymentId);
        verify(paymentRepository, never()).save(any());
    }
}
